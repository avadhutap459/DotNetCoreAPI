﻿

namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public class CountryBM
    {
        public int countryId { get; set; }
        public string countryname { get; set; }
    }
}
