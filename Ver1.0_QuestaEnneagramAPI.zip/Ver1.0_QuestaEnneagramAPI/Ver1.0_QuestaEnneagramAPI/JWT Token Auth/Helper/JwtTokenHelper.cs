﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using V1._0_QuestaEnneagram.InterfaceLayer;
using V1._0_QuestaEnneagram.ModelLayer.Model;

namespace QuestaEnneagramAPI
{
    public class JwtTokenHelper
    {
        private readonly IConfiguration _configuration;
        private ICandidate CandidateCls { get; set; }
        public JwtTokenHelper(IConfiguration configuration, ICandidate CandidateCls)
        {
            _configuration = configuration;
            this.CandidateCls = CandidateCls;
        }

        public Tuple<string, string, DateTime> CandidateLogin(string UserEmail, int UserId)
        {
            var authClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, UserId.ToString()),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                };

            var token = CreateToken(authClaims);
            var refreshToken = GenerateRefreshToken();

            _ = int.TryParse(_configuration["JWT:RefreshTokenValidityInDays"], out int refreshTokenValidityInDays);

            string InsertQuery = "INSERT INTO [dbo].[_RefreshToken](UserId,RefreshToken,RefreshTokenCreatedTime,RefreshTokenExpiryTime)" +
                                    "Values(@UserId,@RefreshToken,@RefreshTokenCreatedTime,@RefreshTokenExpiryTime)";

            var parameters = new
            {
                UserId = UserId,
                RefreshToken = refreshToken,
                RefreshTokenCreatedTime = DateTime.Now,
                RefreshTokenExpiryTime = DateTime.Now.AddDays(refreshTokenValidityInDays)
            };

            CandidateCls.InsertUpdateDeleteForCandidate<Object>(parameters, InsertQuery);

            var GenerateToken = new Tuple<string, string, DateTime>(new JwtSecurityTokenHandler().WriteToken(token), refreshToken, token.ValidTo);

            return GenerateToken;
        }

        public Tuple<string, string, bool, string> RefreshToken(string AccessToken, string RefreshToken)
        {
            var principal = GetPrincipalFromExpiredToken(AccessToken);
            if (principal == null)
            {
                return new Tuple<string, string, bool, string>(string.Empty, string.Empty, false, "Invalid access token or refresh token");
            }
            string UserId = principal.Identity.Name;
            _ = int.TryParse(UserId, out int CandidateId);

            var RefreshTokenModel = CandidateCls.GetRefreshTokenByUserId(CandidateId);

            if (RefreshTokenModel == null || RefreshTokenModel.RefreshToken != RefreshToken || RefreshTokenModel.RefreshTokenExpiryTime <= DateTime.Now)
            {
                return new Tuple<string, string, bool, string>(string.Empty, string.Empty, false, "Invalid access token or refresh token");
            }

            var newAccessToken = CreateToken(principal.Claims.ToList());
            var newRefreshToken = GenerateRefreshToken();

            string UpdateQuery = "UPDATE [dbo].[_RefreshToken] SET RefreshToken = @RefreshToken," +
                                    "RefreshTokenCreatedTime=@RefreshTokenCreatedTime," +
                                 "WHERE UserId=@UserId ";

            var parameters = new
            {
                UserId = UserId,
                RefreshToken = newRefreshToken,
                RefreshTokenCreatedTime = DateTime.Now
            };

            CandidateCls.InsertUpdateDeleteForCandidate<Object>(parameters, UpdateQuery);

            return new Tuple<string, string, bool, string>(new JwtSecurityTokenHandler().WriteToken(newAccessToken),
                RefreshToken, true, "Success");
        }

        public Tuple<string,bool> RevokeParticularUser(int UserId)
        {
            CandidateBM ObjectCandidate = CandidateCls.GetCandidateDetailsByUserId(UserId);

            if (ObjectCandidate == null)
                return new Tuple<string, bool>("No Data found", false);

            string UpdateQuery = "UPDATE [dbo].[_RefreshToken] SET RefreshToken = NULL," +
                                  "WHERE UserId=@UserId ";

            var parameters = new
            {
                UserId = UserId,
            };

            CandidateCls.InsertUpdateDeleteForCandidate<Object>(parameters, UpdateQuery);

            return new Tuple<string, bool>("Success", true);

        }
        private JwtSecurityToken CreateToken(List<Claim> authClaims)
        {
            var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));
            _ = int.TryParse(_configuration["JWT:TokenValidityInMinutes"], out int tokenValidityInMinutes);

            var token = new JwtSecurityToken(
                issuer: _configuration["JWT:ValidIssuer"],
                audience: _configuration["JWT:ValidAudience"],
                expires: DateTime.Now.AddMinutes(tokenValidityInMinutes),
                claims: authClaims,
                signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                );

            return token;
        }

        private static string GenerateRefreshToken()
        {
            var randomNumber = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomNumber);
            return Convert.ToBase64String(randomNumber);
        }

        private ClaimsPrincipal? GetPrincipalFromExpiredToken(string? token)
        {
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateAudience = false,
                ValidateIssuer = false,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"])),
                ValidateLifetime = false
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out SecurityToken securityToken);
            JwtSecurityToken jwtSecurityToken = new JwtSecurityToken();
            if (securityToken != jwtSecurityToken || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
                throw new SecurityTokenException("Invalid token");

            return principal;

        }


    }
}
