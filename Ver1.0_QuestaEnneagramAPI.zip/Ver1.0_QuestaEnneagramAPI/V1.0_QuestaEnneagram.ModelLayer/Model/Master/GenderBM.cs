﻿

namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public class GenderBM
    {
        public int GenderId { get; set; }
        public string GenderName { get; set; }
    }
}
