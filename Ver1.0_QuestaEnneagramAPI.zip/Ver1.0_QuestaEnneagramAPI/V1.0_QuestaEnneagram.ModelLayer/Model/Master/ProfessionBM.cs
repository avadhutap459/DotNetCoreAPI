﻿

namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public class ProfessionBM
    {
        public int ProfessionId { get; set; }
        public string ProfessionName { get; set; }
    }
}
