﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using V1._0_QuestaEnneagram.ModelLayer.Model;

namespace V1._0_QuestaEnneagram.InterfaceLayer
{
    public interface ICandidate
    {
        CandidateBM GetCandidateDetailsByUserId(int UserId);
        CandidateBM GetCandidateDetailsByTestId(int TestId);
        CandidateTestDetailBM GetCandidateTestDetailByTestId(int TestId);
        bool IsDateDifferenceForOneYear(int UserId);
        Task<bool> SaveCandidateDetails(CandidateBM CandidateData);
        RefreshTokenModel GetRefreshTokenByUserId(int UserId);
        void InsertUpdateDeleteForCandidate<T>(T Parameter, string Query);
        void Dispose();
    }
}
