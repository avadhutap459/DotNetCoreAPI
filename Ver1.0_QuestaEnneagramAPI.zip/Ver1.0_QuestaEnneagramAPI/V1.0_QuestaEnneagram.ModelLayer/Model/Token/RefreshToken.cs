﻿using System;
using System.Collections.Generic;
using System.Text;

namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public class RefreshTokenModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string RefreshToken { get; set; }
        public DateTime RefreshTokenCreatedTime { get; set; }
        public DateTime RefreshTokenExpiryTime { get; set; }
    }
}
