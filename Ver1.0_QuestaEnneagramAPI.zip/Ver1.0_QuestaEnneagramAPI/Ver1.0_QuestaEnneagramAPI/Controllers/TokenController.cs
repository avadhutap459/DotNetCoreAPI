﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using QuestaEnneagramAPI.JWT_Token_Auth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuestaEnneagramAPI.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        private readonly IJwtTokenManger _tokenManger;
        public TokenController(IJwtTokenManger tokenManger)
        {
            _tokenManger = tokenManger;
        }

        //[AllowAnonymous]
        //[HttpPost("Authenticate")]
        //public IActionResult Authenticate([FromBody] UserCredentials Credential)
        //{
        //    var token = _tokenManger.Authenticate(Credential.UserName, Credential.Password);

        //    if (string.IsNullOrEmpty(token))
        //        return Unauthorized();

        //    return Ok(token);
        //}

        [HttpGet("GetException")]
        public IActionResult GetException()
        {
            try
            {
                string[] arrRetValues = null;
                if (arrRetValues.Length > 0)
                { }
            }
            catch (Exception ex)
            {
                throw new MyAppException(ex.Message, ex.InnerException);
            }
            return Ok();
        }
    }
}
