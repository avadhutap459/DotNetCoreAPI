﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuestaEnneagramAPI.JWT_Token_Auth
{
    public class Data
    {
        public static Dictionary<string, string> users = new Dictionary<string, string>
        {
            {"SampleUser","password" },
            {"DemoUser","password" },
        };

        
    }
}
