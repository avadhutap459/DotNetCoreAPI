using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using V1._0_QuestaEnneagram.InterfaceLayer;
using V1._0_QuestaEnneagram.ModelLayer.Model;

namespace QuestaEnneagramAPI.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        private ITest TestCls { get; set; }
        private IMaster MasterCls { get; set; }
        private ICandidate CandidateCls { get; set; }
        public ValuesController(ITest TestCls, IMaster MasterCls, ICandidate CandidateCls)
        {
            this.TestCls = TestCls;
            this.MasterCls = MasterCls;
            this.CandidateCls = CandidateCls;
        }

        [HttpGet]
        public IEnumerable<string> Get()
        {
            try
            {
                TestCls.GetRecord();

                MasterBM Obj = MasterCls.GetMasterData().Result;

                List<StateBM> state = MasterCls.GetStateDetailsByCountryId(1).Result;
                CandidateBM ObjCandidate = CandidateCls.GetCandidateDetailsByTestId(10330);
            }
            catch (Exception ex)
            {
                throw new MyAppException(ex.Message, ex.InnerException);
            }
            finally
            {
                if (MasterCls != null)
                {
                    MasterCls.Dispose();
                }
            }
            
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
