﻿using System;

namespace V1._0_QuestaEnneagram.InterfaceLayer
{
    public class Class1
    {
    }
}
