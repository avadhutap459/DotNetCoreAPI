﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using QuestaEnneagramAPI.JWT_Token_Auth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuestaEnneagramAPI.Controllers
{
    [Authorize]
    //[CustomAuthorization]
    [Route("api/[controller]")]
    [ApiController]
    public class NameController : ControllerBase
    {
        [HttpGet("GetNames")]
        public  IActionResult GetName()
        {
            var token = HttpContext.GetTokenAsync("access_token").Result;

            return Ok(new List<string> { "Jack", "Waren" });
        }
    }
}
