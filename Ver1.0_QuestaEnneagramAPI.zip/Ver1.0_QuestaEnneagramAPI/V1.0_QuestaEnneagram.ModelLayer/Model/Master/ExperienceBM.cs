﻿

namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public  class ExperienceBM
    {
        public int ExperenceId { get; set; }
        public string ExperenceName { get; set; }
    }
}
