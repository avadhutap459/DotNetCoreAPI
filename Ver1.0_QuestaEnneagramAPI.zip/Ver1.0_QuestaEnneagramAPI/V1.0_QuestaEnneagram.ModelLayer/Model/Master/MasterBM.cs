﻿using System.Collections.Generic;

namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public class MasterBM
    {
        public List<AgeBM> Ages { get; set; }
        public List<CountryBM> Countries { get; set; }
        public List<QualificationBM> Qualification { get; set; }
        public List<EmployeeStatusBM> EmployeeStatus { get; set; }
        public List<GenderBM> Gender { get; set; }
        public List<IndustryBM> Industry { get; set; }
        public List<MaritalStatusBM> MaritalStatus { get; set; }
        public List<ProfessionBM> professional { get; set; }
        public List<ExperienceBM> Experience { get; set; }
    }
}
