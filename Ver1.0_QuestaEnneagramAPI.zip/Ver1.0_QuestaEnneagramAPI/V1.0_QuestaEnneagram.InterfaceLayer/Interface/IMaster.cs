﻿using System.Collections.Generic;
using System.Threading.Tasks;
using V1._0_QuestaEnneagram.ModelLayer.Model;

namespace V1._0_QuestaEnneagram.InterfaceLayer
{
    public interface IMaster
    {
        Task<MasterBM> GetMasterData();
        Task<List<StateBM>> GetStateDetailsByCountryId(int CountryId);
        void Dispose();
    }
}
