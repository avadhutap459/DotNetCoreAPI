﻿

namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public class StateBM
    {
        public int stateId { get; set; }
        public int countryId { get; set; }
        public string statename { get; set; }
    }
}
