﻿
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;

namespace V1._0_QuestaEnneagram.DataLayer
{
    public class Class1
    {
        IConfigurationRoot configuration = new ConfigurationBuilder()
              .SetBasePath(Directory.GetCurrentDirectory())
              .AddJsonFile("appsettings.json")
              .Build();

        //  var connectionString = configuration.GetConnectionString("DefaultConnection");

        public IDbConnection connection
        {
            get
            {
                //   return new SqlConnection(ConfigurationManager.ConnectionStrings["SalesQueryConnectionString"].ConnectionString);

                return new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
            }
        }



    }

   public sealed class SingletonDBConnection
    {
        IConfigurationRoot configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json")
            .Build();
        private static SingletonDBConnection singleInstance = null;
        private static readonly object lockObject = new object();
        private SingletonDBConnection(){}

        public static SingletonDBConnection SingleInstance
        {
            get
            {
                lock (lockObject)
                {
                    if (singleInstance == null)
                    {
                        singleInstance = new SingletonDBConnection();
                    }

                }
                return singleInstance;
            }
        }
        public IDbConnection connection
        {
            get
            {
                return new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
            }
        }

        public T RetrunModelFromDB<T,T1>(T1 Query, Dictionary<string, object> Parameters) 
        {
            T ObjectModel;
            using (IDbConnection cn = connection)
            {
                cn.Open();
                ObjectModel = cn.Query<T>(Query.ToString(), Parameters).FirstOrDefault();
            }
            return ObjectModel;
        }
        public void DMLOperationFromDB<T>( T Query, Object ObjectParam) 
        {
            using (IDbConnection cn = connection)
            {
                cn.Open();
                cn.Execute(Query.ToString(), ObjectParam);
            }
        }
    }
}
