﻿using System;
using System.Collections.Generic;
using System.Text;

namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
     public class CandidateBM
    {
        public Nullable<int> UserId { get; set; }
        public int TestId { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserEmail { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public Nullable<int> UserGender { get; set; }
        public string GenderTxt { get; set; }
        public int UserAge { get; set; }
        public int State { get; set; }
        public int Country { get; set; }
        public int Qualification { get; set; }
        public string QualificationTxt { get; set; }
        public int Professional { get; set; }
        public int MaritalStatus { get; set; }
        public string[] Industry { get; set; }
        public int EmployeeStatus { get; set; }
        public int Experience { get; set; }
        public bool IsActive { get; set; }
        public bool IsLoginByMobileDevice { get; set; }
        public bool IsLoginByDesktopDevice { get; set; }
        public bool IsLoginByTabDevice { get; set; }
        public string BrowserName { get; set; }
        public bool IsLogin { get; set; }
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModifedAt { get; set; }
        public string LastModifiedBy { get; set; }
    }



    public class CandidateTestDetailBM
    {
        public int TestId { get; set; }
        public int UserId { get; set; }
        public string ExamStatus { get; set; }
        public DateTime CreatedAt { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastModifiedAt { get; set; }
        public string LastModifiedBy { get; set; }
    }

}
