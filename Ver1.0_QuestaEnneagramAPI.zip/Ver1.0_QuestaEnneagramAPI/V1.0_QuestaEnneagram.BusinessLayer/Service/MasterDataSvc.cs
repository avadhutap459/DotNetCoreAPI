﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using V1._0_QuestaEnneagram.DataLayer;
using V1._0_QuestaEnneagram.InterfaceLayer;
using V1._0_QuestaEnneagram.ModelLayer.Model;

namespace V1._0_QuestaEnneagram.BusinessLayer
{
    public class MasterDataSvc : IMaster, IDisposable
    {
        SingletonDBConnection ConnectionManager;
        // Flag: Has Dispose already been called?
        bool disposed = false;

        public MasterDataSvc()
        {
            ConnectionManager = SingletonDBConnection.SingleInstance;
        }
        ~MasterDataSvc()
        {
            Dispose(false);
        }

        public async Task<MasterBM> GetMasterData()
        {
            try
            {
                MasterBM objBModel = new MasterBM();
                const string GetMasterRow = @"SP_GetMasterData";
                await Task.Run(() => {
                    using (IDbConnection cn = ConnectionManager.connection)
                    {
                        cn.Open();
                        var data = cn.QueryMultiple(GetMasterRow, commandType: CommandType.StoredProcedure);

                        objBModel.Countries = data.Read<CountryBM>().ToList();
                        objBModel.Qualification = data.Read<QualificationBM>().ToList();
                        objBModel.professional = data.Read<ProfessionBM>().ToList();
                        objBModel.Ages = data.Read<AgeBM>().ToList();
                        objBModel.Gender = data.Read<GenderBM>().ToList();
                        objBModel.MaritalStatus = data.Read<MaritalStatusBM>().ToList();
                        objBModel.EmployeeStatus = data.Read<EmployeeStatusBM>().ToList();
                        objBModel.Industry = data.Read<IndustryBM>().ToList();
                        objBModel.Experience = data.Read<ExperienceBM>().ToList();
                    }

                });

                return objBModel;
            }
            catch
            {
                throw;
            }
           
        }

        public async Task<List<StateBM>> GetStateDetailsByCountryId(int CountryId)
        {
            try
            {
                List<StateBM> LstState = new List<StateBM>();
                var query = "SELECT * FROM [dbo].[_mstState] WHERE IsActive=@Active And CountryId=@CountryId";
                var parameters = new Dictionary<string, object>()
                {
                    ["Active"] = "1",
                    ["CountryId"] = CountryId
                };

                await Task.Run(() =>
                {
                    using (IDbConnection cn = ConnectionManager.connection)
                    {
                        cn.Open();
                        LstState = cn.Query<StateBM>(query, parameters).ToList();

                    }
                });

                return LstState;
            }
            catch
            {
                throw;
            }
        }


        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                // Console.WriteLine("This is the first call to Dispose. Necessary clean-up will be done!");

                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                    // Console.WriteLine("Explicit call: Dispose is called by the user.");
                }
                else
                {
                    // Console.WriteLine("Implicit call: Dispose is called through finalization.");
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // Console.WriteLine("Unmanaged resources are cleaned up here.");

                // TODO: set large fields to null.

                disposedValue = true;
            }
            else
            {
                // Console.WriteLine("Dispose is called more than one time. No need to clean up!");
            }
        }



        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            GC.SuppressFinalize(this);
        }
        #endregion


    }
}
