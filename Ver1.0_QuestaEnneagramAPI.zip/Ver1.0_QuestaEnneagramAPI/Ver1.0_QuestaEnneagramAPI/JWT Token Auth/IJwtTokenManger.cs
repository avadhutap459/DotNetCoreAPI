﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuestaEnneagramAPI.JWT_Token_Auth
{
    public interface IJwtTokenManger
    {
        string Authenticate(string userName, string password);
    }
}
