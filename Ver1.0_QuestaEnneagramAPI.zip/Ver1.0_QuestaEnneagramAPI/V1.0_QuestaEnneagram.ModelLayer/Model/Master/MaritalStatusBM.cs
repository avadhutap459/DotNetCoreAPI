﻿
namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public class MaritalStatusBM
    {
        public int MaritalId { get; set; }
        public string MaritalName { get; set; }
    }
}
