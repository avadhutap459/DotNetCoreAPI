﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using V1._0_QuestaEnneagram.DataLayer;
using V1._0_QuestaEnneagram.InterfaceLayer;
using V1._0_QuestaEnneagram.ModelLayer.Model;

namespace V1._0_QuestaEnneagram.BusinessLayer
{
    public class CandidateSvc : ICandidate, IDisposable
    {
        SingletonDBConnection ConnectionManager;
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        // Flag: Has Dispose already been called?
        bool disposed = false;

        public CandidateSvc()
        {
            ConnectionManager = SingletonDBConnection.SingleInstance;
        }
        ~CandidateSvc()
        {
            Dispose(false);
        }
        public CandidateBM GetCandidateDetailsByUserId(int UserId)
        {
            try
            {
                string query = "SELECT * FROM [dbo].[txnCandidate] WHERE UserId=@UserId";

                var parameters = new Dictionary<string, object>()
                {
                    ["UserId"] = UserId
                };

                CandidateBM objCandidate = ConnectionManager.RetrunModelFromDB<CandidateBM,string>( query, parameters);

                return objCandidate;
            }
            catch
            {
                throw;
            }
        }
        public CandidateBM GetCandidateDetailsByTestId(int TestId)
        {
            try
            {
                var query = "select C.UserId As UserId,UT.TestId As TestId," +
                            "C.Title As Title,C.FirstName As FirstName," +
                            "C.LastName As LastName,C.UserEmail As UserEmail," +
                            "C.PhoneNumber As PhoneNumber,C.UserDateOfBirth As DateOfBirth," +
                            "C.UserGender," +
                            "case when C.UserGender > 4  then k.GenderName Else '' End GenderTxt," +
                            "C.UserAge As UserAge,C.UserState As State,C.UserCountry As Country," +
                            "C.UserQualification As  Qualification, " +
                            "case when C.UserQualification > 8  then l.QualificationName Else '' End QualificationTxt," +
                            "C.UserProfessional As Professional,C.UserMaritalStatus As MaritalStatus," +
                            "C.UserEmployeeStatus As EmployeeStatus,C.UserExperience As Experience," +
                            "C.IsActive As IsActive,C.IsMobileDevice As IsLoginByMobileDevice," +
                            "C.IsDesktopDevice As IsLoginByDesktopDevice,C.IsTabDevice As IsLoginByTabDevice," +
                            "C.BrowserName As BrowserName,C.IsLogin As IsLogin," +
                            "C.CreatedAt As CreatedAt,C.CreatedBy As CreatedBy," +
                            "C.LastModifiedAt As LastModifedAt,C.LastModifiedBy As LastModifiedBy" +
                            "FROM _txnCandidate C INNER JOIN _txnUserTestDetails UT on C.UserId = UT.UserId" +
                            "LEFT OUTER JOIN _mstGender k on i.UserGender = k.GenderId" +
                            "LEFT OUTER JOIN [dbo].[_mstQualification] l on i.UserQualification = l.QualificationId" +
                            "WHERE j.TestId = @TestId";

                var parameters = new Dictionary<string, object>()
                {
                    ["TestId"] = TestId
                };

                CandidateBM objCandidate = ConnectionManager.RetrunModelFromDB<CandidateBM, string>(query, parameters);

                return objCandidate;
            }
            catch
            {
                throw;
            }
        }
        public CandidateTestDetailBM GetCandidateTestDetailByTestId(int TestId)
        {
            try
            {
                var query = "SELECT * FROM [dbo].[txnUserTestDetails] WHERE TestId=@TestId";
                var parameters = new Dictionary<string, object>()
                {
                    ["TestId"] = TestId
                };
                CandidateTestDetailBM objCandidateTestDetail = ConnectionManager.RetrunModelFromDB<CandidateTestDetailBM, string>(query, parameters);
               
                return objCandidateTestDetail;
            }
            catch
            {
                throw;
            }
        }

        public bool IsDateDifferenceForOneYear(int UserId)
        {
            try
            {
                DateTime CurrentDateTime = DateTime.Now;

                CandidateBM ObjectCandidate = GetCandidateDetailsByUserId(UserId);

                var daydiff = (Convert.ToDateTime(ObjectCandidate.DateOfBirth) - CurrentDateTime).TotalDays;

                if (daydiff > 365)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public static DataTable CreateDataTable(object ClassObject)
        {
            DataTable return_Datatable = new DataTable();
            Type t = ClassObject.GetType();
            foreach (System.Reflection.PropertyInfo info in t.GetProperties())
            {
                return_Datatable.Columns.Add(new DataColumn(info.Name, info.PropertyType));
            }

            DataRow dr = return_Datatable.NewRow();
            foreach (DataColumn dc in return_Datatable.Columns)
            {
                dr[dc.ColumnName] = ClassObject.GetType().GetProperty(dc.ColumnName).GetValue(ClassObject, null);
            }
            return_Datatable.Rows.Add(dr);


            return return_Datatable;
        }

        public async Task<bool> SaveCandidateDetails(CandidateBM CandidateData)
        {
            bool IsSuccess;
            try
            {
                await Task.Run(() =>
                {

                    DataTable DTCandidateModel = CreateDataTable(CandidateData);

                    //For DataTable, start from here
                    using (IDbConnection cn = ConnectionManager.connection)
                    {
                        cn.Open();

                        cn.Execute("SP_UpdateCandidateModel",
                                    new { CandidateModel = DTCandidateModel.AsTableValuedParameter("dbo.UT_CandidateModel") },
                                          commandType: CommandType.StoredProcedure);

                    }

                });

                IsSuccess = true;
            }
            catch (Exception ex)
            {
                IsSuccess = false;

                throw;
            }
            return IsSuccess;
        }


        public RefreshTokenModel GetRefreshTokenByUserId(int UserId)
        {
            try
            {
                var query = "SELECT * FROM [dbo].[_RefreshToken] WHERE UserId=@UserId";
                var parameters = new Dictionary<string, object>()
                {
                    ["UserId"] = UserId
                };

                RefreshTokenModel ObjectRefreshToken = ConnectionManager.RetrunModelFromDB<RefreshTokenModel, string>(query, parameters);

                return ObjectRefreshToken;
            }
            catch
            {
                throw;
            }
        }

        public void InsertUpdateDeleteForCandidate<T>(T Parameter,string Query)
        {
            try
            {
                ConnectionManager.DMLOperationFromDB<string>( Query, Parameter);
            }
            catch
            {
                throw;
            }
        }




        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                // Console.WriteLine("This is the first call to Dispose. Necessary clean-up will be done!");

                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                    // Console.WriteLine("Explicit call: Dispose is called by the user.");
                }
                else
                {
                    // Console.WriteLine("Implicit call: Dispose is called through finalization.");
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // Console.WriteLine("Unmanaged resources are cleaned up here.");

                // TODO: set large fields to null.

                disposedValue = true;
            }
            else
            {
                // Console.WriteLine("Dispose is called more than one time. No need to clean up!");
            }
        }



        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}
