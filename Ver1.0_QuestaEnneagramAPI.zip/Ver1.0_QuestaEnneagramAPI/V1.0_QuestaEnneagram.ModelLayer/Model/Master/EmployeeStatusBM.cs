﻿

namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public class EmployeeStatusBM
    {
        public int EmploymentId { get; set; }
        public string EmploymentName { get; set; }
    }
}
