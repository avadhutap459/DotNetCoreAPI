﻿using System;

namespace V1._0_QuestaEnneagram.BusinessLayer
{
    public class Class1
    {
    }
}
