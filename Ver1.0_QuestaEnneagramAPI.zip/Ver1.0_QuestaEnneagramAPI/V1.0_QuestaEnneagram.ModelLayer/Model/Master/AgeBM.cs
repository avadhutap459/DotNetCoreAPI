﻿

namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public class AgeBM
    {
        public int AgeId { get; set; }
        public string AgeName { get; set; }
    }
}
