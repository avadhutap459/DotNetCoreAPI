﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using V1._0_QuestaEnneagram.InterfaceLayer;
using V1._0_QuestaEnneagram.ModelLayer.Model;

namespace QuestaEnneagramAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CandidateController : ControllerBase
    {
        private IMaster MasterCls { get; set; }
        private ICandidate CandidateCls { get; set; }

        private readonly IConfiguration _configuration;

        public CandidateController(IMaster MasterCls, ICandidate CandidateCls, IConfiguration configuration)
        {
            this.MasterCls = MasterCls;
            this.CandidateCls = CandidateCls;
            _configuration = configuration;
        }
        [HttpGet]
        [Route("{TestId}")]
        public IActionResult GetCandiateDetails(int TestId)
        {
            try
            {
                bool IsDisableAllControl = false;

                #region GetMasterDetails

                MasterBM MasterData = MasterCls.GetMasterData().Result;

                #endregion

                #region Get Candidate Details

                CandidateBM CandidateData = CandidateCls.GetCandidateDetailsByTestId(TestId);

                if (CandidateData.UserId == null)
                {
                    return NotFound(new { IsSuccess = false, message = "User does not exit in current database" });
                }
                IsDisableAllControl = CandidateData.UserGender == null ? true : false;

                #endregion

                return Ok(new { IsSuccess = true, MasterObject = MasterData, CandidateObject = CandidateData, IsDisableAllControl = IsDisableAllControl });
            }
            catch (Exception ex)
            {
                throw new MyAppException(ex.Message, ex.InnerException);
            }
            finally
            {
                this.MasterCls.Dispose();

                this.CandidateCls.Dispose();
            }

        }

        [HttpGet]
        [Route("{CountryId}")]
        public async Task<IActionResult> GetState(int CountryId)
        {
            try
            {
                List<StateBM> StateList = MasterCls.GetStateDetailsByCountryId(CountryId).Result;

                return Ok(new { StateObject = StateList });
            }
            catch (Exception ex)
            {
                throw new NotImplementedException(ex.Message);
            }
            finally
            {
                this.MasterCls.Dispose();
            }
        }

        [HttpPost]
        public IActionResult SaveCandidateDetails(CandidateBM CandidateModel)
        {
            CandidateModel.DateOfBirth = CandidateModel.DateOfBirth == null ? (DateTime?)null : CandidateModel.DateOfBirth.Value.AddDays(1);

            // JWT_Token_Auth.Service.JWT_TokenService ObjectToken = new JWT_Token_Auth.Service.JWT_TokenService(CandidateCls);
           
            JwtTokenHelper ObjectToken = new JwtTokenHelper(_configuration, CandidateCls);

            if (CandidateModel.IsActive)
            {
                if (CandidateCls.IsDateDifferenceForOneYear(CandidateModel.UserId.Value))
                {
                    return Ok(new
                    {
                        message = "Please Note : The link you clicked on has expired,as ie was valid for a duration of 15 days from the date of payment Please contact us at support@questaenneagram.com for further assistance. ",
                        isSuccess = false
                    });
                }
                else
                {
                    bool IsSucess = CandidateCls.SaveCandidateDetails(CandidateModel).Result;

                    if(CandidateCls.SaveCandidateDetails(CandidateModel).Result)
                    {
                        var Token = ObjectToken.CandidateLogin(CandidateModel.UserEmail, CandidateModel.UserId.Value);

                        return Ok(new { ExamId = CandidateModel.TestId, isSuccess = true, Token });
                    }
                    else
                    {
                        return BadRequest();
                    }

                    //var loginResponse = ObjectToken.LoginAsync(CandidateModel.UserId.Value, CandidateModel.UserEmail).Result;

                    //if (!loginResponse.Success)
                    //{
                    //    return Unauthorized(new
                    //    {
                    //        loginResponse.ErrorCode,
                    //        loginResponse.Error
                    //    });
                    //}


                    //setTokenCookie(loginResponse.RefreshToken);

                    //return Ok(new { ExamId = CandidateModel.TestId, isSuccess = IsSucess, loginResponse });

                }
            }
            else
            {
                return Ok(new { message = "Particular candidate does not available", IsSuccess = false });
            }

            //  return Ok();
        }




        [HttpPost]
        [Route("refresh-token")]
        public async Task<IActionResult> RefreshToken(TokenModel tokenModel)
        {
            JwtTokenHelper ObjectToken = new JwtTokenHelper(_configuration, CandidateCls);

            if (tokenModel is null)
            {
                return BadRequest("Invalid client request");
            }

            string? accessToken = tokenModel.AccessToken;
            string? refreshToken = tokenModel.RefreshToken;

            var Data = ObjectToken.RefreshToken(accessToken, refreshToken);

            if(!Data.Item3)
            {
                return BadRequest(Data.Item4);
            }
            else
            {
                return new ObjectResult(new
                {
                    accessToken = Data.Item1,
                    refreshToken = Data.Item2
                });
            }

        }

        [Authorize]
        [HttpPost]
        [Route("revoke/{UserId}")]
        public async Task<IActionResult> Revoke(int UserId)
        {
            JwtTokenHelper ObjectToken = new JwtTokenHelper(_configuration, CandidateCls);

            var Data = ObjectToken.RevokeParticularUser(UserId);

            if(Data.Item2)
                return NotFound(new { message = Data.Item1});

            return Ok(new { message = Data.Item1 });

        }

        //[HttpPost]
        //[Route("refresh_token")]
        //public async Task<IActionResult> RefreshToken(JWT_Token_Auth.Models.RefreshTokenRequest refreshTokenRequest)
        //{
        //    var refreshToken = Request.Cookies["refreshToken"];

        //    JWT_Token_Auth.Service.JWT_TokenService ObjectToken = new JWT_Token_Auth.Service.JWT_TokenService(CandidateCls);

        //    if (refreshTokenRequest == null || string.IsNullOrEmpty(refreshTokenRequest.RefreshToken) || refreshTokenRequest.UserId == 0)
        //    {
        //        return BadRequest(new JWT_Token_Auth.Models.TokenResponse
        //        {
        //            Error = "Missing refresh token details",
        //            ErrorCode = "R01"
        //        });
        //    }

        //    var validateRefreshTokenResponse = await ObjectToken.ValidateRefreshTokenAsync(refreshTokenRequest);

        //    if (!validateRefreshTokenResponse.Success)
        //    {
        //        return UnprocessableEntity(validateRefreshTokenResponse);
        //    }

        //    var tokenResponse = await ObjectToken.GenerateTokensAsync(validateRefreshTokenResponse.UserId);

        //    return Ok(new { AccessToken = tokenResponse.Item1, Refreshtoken = tokenResponse.Item2 });

        //}
        private void setTokenCookie(string token)
        {
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddDays(7)
            };
            Response.Cookies.Append("refreshToken", token, cookieOptions);
        }
    }
}
