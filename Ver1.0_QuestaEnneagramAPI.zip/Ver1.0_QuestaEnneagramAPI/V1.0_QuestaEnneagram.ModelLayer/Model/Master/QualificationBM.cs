﻿
namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public class QualificationBM
    {
        public int QualificationId { get; set; }
        public string QualificationName { get; set; }
    }
}
