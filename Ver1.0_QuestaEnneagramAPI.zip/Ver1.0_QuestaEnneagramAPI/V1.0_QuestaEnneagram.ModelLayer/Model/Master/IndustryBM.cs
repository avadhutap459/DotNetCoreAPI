﻿
namespace V1._0_QuestaEnneagram.ModelLayer.Model
{
    public class IndustryBM
    {
        public int IndustryId { get; set; }
        public string IndustryName { get; set; }
    }
}
