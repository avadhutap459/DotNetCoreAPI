﻿using System;
using System.Collections.Generic;
using System.Text;

namespace V1._0_QuestaEnneagram.InterfaceLayer
{
    public interface ITest
    {
        void GetRecord();
    }
}
