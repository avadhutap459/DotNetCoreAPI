﻿using System;

namespace V1._0_QuestaEnneagram.ModelLayer
{
    public class Class1
    {
    }
}
