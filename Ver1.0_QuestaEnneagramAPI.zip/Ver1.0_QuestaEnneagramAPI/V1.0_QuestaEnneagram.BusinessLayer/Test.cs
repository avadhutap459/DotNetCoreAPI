﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using V1._0_QuestaEnneagram.InterfaceLayer;
using V1._0_QuestaEnneagram.DataLayer;
using Dapper;
using System.Linq;

namespace V1._0_QuestaEnneagram.BusinessLayer
{
    public class Test : ITest
    {
        SingletonDBConnection fromManager = SingletonDBConnection.SingleInstance;
        public void GetRecord()
        {
            using (IDbConnection cn = fromManager.connection)
            {
                cn.Open();
                var data =  cn.Query("select * from mstAge").AsList();
            }
        }
    }
}
